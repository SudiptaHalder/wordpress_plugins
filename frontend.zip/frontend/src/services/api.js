const BASE_URL = "https://meritless-charise-pseudodiphtheric.ngrok-free.dev";

async function request(url) {
  try {
    const response = await fetch(url);

    const text = await response.text();

    // If backend returned HTML → error
    if (text.startsWith("<!DOCTYPE")) {
      throw new Error("Server returned HTML instead of JSON");
    }

    return JSON.parse(text);

  } catch (err) {
    console.error("API ERROR:", err);
    throw err;
  }
}

export const analyticsAPI = {
  getOverview: (siteId, start, end) =>
    request(`${BASE_URL}/api/overview?site_id=${siteId}&start_date=${start}&end_date=${end}`),

  getTraffic: (siteId, start, end) =>
    request(`${BASE_URL}/api/traffic?site_id=${siteId}&start_date=${start}&end_date=${end}`),

  getActiveUsers: (siteId) =>
    request(`${BASE_URL}/api/realtime/active?site_id=${siteId}`),

  getRecentActivities: (siteId) =>
    request(`${BASE_URL}/api/realtime/activities?site_id=${siteId}`),
};
